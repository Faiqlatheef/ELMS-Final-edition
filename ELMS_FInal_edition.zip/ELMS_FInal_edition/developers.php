<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/siyam.jpg" class="img-circle">
										<hr>
										<p>Name: Zamroot Siyam</p>
										<p>Address: Eravur</p>
										<p>Email: zamroot11@gmail.com</p>
										<p>Position: Programmering student</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/faiq.jpg" class="img-circle">
								<hr>
									    <p>Name: Faiq Lathif</p>
										<p>Address: kathankudy</p>
										<p>Email: faiqlathif@gmail.com</p>
										<p>Position: Programmering student</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers"  class="img-circle">
								<hr>
										<p>Name: Raygin</p>
										<p>Address: Batticalo</p>
										<p>Email: rayginloudsasi@gmail.com</p>
										<p>Position: Programmering student</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/thiru.jpg" class="img-circle">
								<hr>
										<p>Name: Thiru</p>
										<p>Address: tricomalee</p>
										<p>Email: thiru4891@gmail.com</p>
										<p>Position: Programmering student</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>