<?php
include('admin/dbcon.php');
include('session.php');
$student_id = $_POST['#student_id'];
$amount = $_POST['#amount'];


$query = mysqli_query($conn,"select * from student where student_id = '$student_id'")or die(mysqli_error());
$row = mysqli_fetch_array($query);
$name = $row['firstname']." ".$row['lastname'];

$query1 = mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'")or die(mysqli_error());
$row1 = mysqli_fetch_array($query1);
$name1 = $row1['firstname']." ".$row1['lastname'];


mysqli_query($conn,"insert into payment(techer_name,student_name,student_id,amount,date) values('$name1','$name','$student_id','$amount',NOW()")or die(mysqli_error());

?>