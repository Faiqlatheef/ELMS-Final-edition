<?php
$conn = mysqli_connect('localhost','root','','e_school_db') or die(mysqli_error());
?>