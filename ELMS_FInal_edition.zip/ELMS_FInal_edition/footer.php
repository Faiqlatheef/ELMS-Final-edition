<center>
		<footer>
		
		<p>E-School ELMS Copyright 2020</p>
			<!-- <p>Programmed by: zamroot siyam and team</p> -->
		</footer>
</center>

